export interface Scooter {
  id: string,
  is_available: boolean,
  total_distance: number,
  current_reservation_id: string,
}
