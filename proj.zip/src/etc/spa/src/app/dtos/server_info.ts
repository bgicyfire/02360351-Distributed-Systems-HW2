export interface ServerInfo {
  member_id: string;
  leader_id: string;
  is_leader: boolean;
}
