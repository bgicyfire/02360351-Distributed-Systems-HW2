export const environment = {
  scootersApiUrl: 'http://localhost:50053',
};
